import "./App.css";
import LikeButton from "./LikesTask/LikeButton";

function App() {
  return (
    <>
      <LikeButton />
    </>
  );
}

export default App;
