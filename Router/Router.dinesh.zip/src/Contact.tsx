import React from "react";

function Contact() {
  return (
    <div>
      <h1> Contact Number : 7780293933</h1>
    </div>
  );
}

export default Contact;
