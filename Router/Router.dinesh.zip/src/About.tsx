import React from "react";

function About() {
  return (
    <div>
      <h1>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Dicta,</h1>
    </div>
  );
}

export default About;
