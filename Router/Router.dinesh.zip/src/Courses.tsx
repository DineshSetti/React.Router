import React from "react";

function Courses() {
  return (
    <div>
      <h1>ECE,CSE,EEE,MECH</h1>
    </div>
  );
}

export default Courses;
